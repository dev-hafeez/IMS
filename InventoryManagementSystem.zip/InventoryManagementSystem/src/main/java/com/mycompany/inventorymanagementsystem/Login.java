
package com.mycompany.inventorymanagementsystem;

public class Login {
    private String id;
    private String password;

    public Login(String id, String password) {
        this.id = id;
        this.password = password;
    }

    public boolean login(String inputId, String inputPassword) {
        return id.equals(inputId) && password.equals(inputPassword);
    }
}
