
package com.mycompany.inventorymanagementsystem;


import java.util.ArrayList;
import java.util.List;

public class Inventory {
    private List<Product> products;

    public Inventory() {
        products = new ArrayList<>();
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public void removeProduct(String productID) {
        products.removeIf(product -> product.getID().equals(productID));
    }

    public List<Product> getProducts() {
        return products;
    }
}
