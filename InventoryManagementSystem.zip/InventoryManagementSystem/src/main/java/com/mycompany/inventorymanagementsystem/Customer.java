
package com.mycompany.inventorymanagementsystem;


public class Customer {
    private String name;

    public Customer(String name) {
        this.name = name;
    }

    public void viewProducts(Inventory inventory) {
        for (Product product : inventory.getProducts()) {
            System.out.println(product);
        }
    }

    public void buyProduct(Inventory inventory, String productID) {
        Product productToBuy = null;
        for (Product product : inventory.getProducts()) {
            if (product.getID().equals(productID)) {
                productToBuy = product;
                break;
            }
        }
        if (productToBuy != null) {
            System.out.println("Purchased: " + productToBuy);
        } else {
            System.out.println("Product not found.");
        }
    }
}
