
package com.mycompany.inventorymanagementsystem;


import java.io.Serializable;

public class Order implements Serializable {
    private String orderNumber;
    private String customerID;

    public Order(String orderNumber, String customerID) {
        this.orderNumber = orderNumber;
        this.customerID = customerID;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public String getCustomerID() {
        return customerID;
    }
}

