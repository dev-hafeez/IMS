
package com.mycompany.inventorymanagementsystem;


public class Admin {
    private Inventory inventory;

    public Admin(Inventory inventory) {
        this.inventory = inventory;
    }

    public void addProduct(Product product) {
        inventory.addProduct(product);
    }

    public void removeProduct(String productID) {
        inventory.removeProduct(productID);
    }

    public void seeProducts() {
        for (Product product : inventory.getProducts()) {
            System.out.println(product);
        }
    }
}
