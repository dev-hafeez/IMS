
package com.mycompany.inventorymanagementsystem;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.List;

public class InventoryManagementSystem {
    private Inventory inventory;
    private Admin admin;
    private Customer customer;

    public InventoryManagementSystem() {
        inventory = new Inventory();
        admin = new Admin(inventory);
        customer = new Customer("Customer1");
    }

    public void saveInventory() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("inventory.dat"))) {
            oos.writeObject(inventory.getProducts());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadInventory() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("inventory.dat"))) {
            List<Product> products = (List<Product>) ois.readObject();
            for (Product product : products) {
                inventory.addProduct(product);
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void showGUI() {
        JFrame frame = new JFrame("Inventory Management System");
        frame.setDefaultCloseOperation(3);
        frame.setSize(400, 300);

        JTabbedPane tabbedPane = new JTabbedPane();

        
        JPanel adminPanel = new JPanel();
        adminPanel.setLayout(new BoxLayout(adminPanel, BoxLayout.Y_AXIS));

        JTextField productIdField = new JTextField(10);
        JTextField productNameField = new JTextField(10);
        JTextField productPriceField = new JTextField(10);
        JButton addProductButton = new JButton("Add Product");
        JButton removeProductButton = new JButton("Remove Product");
        JButton seeProductsButton = new JButton("See Products");

        adminPanel.add(new JLabel("Product ID:"));
        adminPanel.add(productIdField);
        adminPanel.add(new JLabel("Product Name:"));
        adminPanel.add(productNameField);
        adminPanel.add(new JLabel("Product Price:"));
        adminPanel.add(productPriceField);
        adminPanel.add(addProductButton);
        adminPanel.add(removeProductButton);
        adminPanel.add(seeProductsButton);

        addProductButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = productIdField.getText();
                String name = productNameField.getText();
                double price = Double.parseDouble(productPriceField.getText());
                admin.addProduct(new Product(id, name, price));
                saveInventory();
            }
        });

        removeProductButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = productIdField.getText();
                admin.removeProduct(id);
                saveInventory();
            }
        });

        seeProductsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                admin.seeProducts();
            }
        });

        
        JPanel customerPanel = new JPanel();
        customerPanel.setLayout(new BoxLayout(customerPanel, BoxLayout.Y_AXIS));

        JButton viewProductsButton = new JButton("View Products");
        JTextField buyProductIdField = new JTextField(10);
        JButton buyProductButton = new JButton("Buy Product");

        customerPanel.add(viewProductsButton);
        customerPanel.add(new JLabel("Product ID to buy:"));
        customerPanel.add(buyProductIdField);
        customerPanel.add(buyProductButton);

        viewProductsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                customer.viewProducts(inventory);
            }
        });

        buyProductButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = buyProductIdField.getText();
                customer.buyProduct(inventory, id);
            }
        });

        tabbedPane.addTab("Admin", adminPanel);
        tabbedPane.addTab("Customer", customerPanel);

        frame.add(tabbedPane);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        InventoryManagementSystem ims = new InventoryManagementSystem();
        ims.loadInventory();
        ims.showGUI();
        
    }
}
